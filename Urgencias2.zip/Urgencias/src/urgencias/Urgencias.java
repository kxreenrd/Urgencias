/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package urgencias;

/**
 *
 * @author Karen Rodriguez
 */
public class Urgencias {

    /**
     * @param args the command line arguments
     */
    double[][] poisson_m;
    double[][] final_m;
    int paciente = 1;
    int minutos, tiempo;
    double rnd_poisson, sum =0;
    
    double poisson(double x){
        double e = Math.E;
        double elevado = 0.0009118;//(Math.pow(e, (-7)));
        double mult = Math.pow(7, x);
        double fact = factorial(x);
        
        return redondearDecimales(((elevado * mult) / fact),4);
    }
    
    public double factorial (double numero) {
        if (numero <= 0) {
            return 1;
        } else {
            return numero * factorial(numero - 1);
        }
    }
    
    
    void tiempo_entrada(int min){
        minutos = min;
        tabla_poisson();
        final_m=new double[minutos][];
        
        System.out.print(" [Minuto]");
        System.out.print(" [Paci.]");
        System.out.print(" [Doc.1]");
        System.out.print(" [Doc. 2]");
        System.out.print("  [Tiempo]");
        System.out.println("");
        
        for (int i = 1; i < minutos; i++) { 
            final_m[i]=new double[8];
            final_m[i][0] = i;
        }
        determinar_poisson();
        tiempo_paciente(1);
        //System.out.println("------------------------------------------");
        mostrar();
    }
    
    void determinar_poisson(){
        rnd_poisson = redondearDecimales(Math.random(), 3);
        //System.out.println("Random poisson "+rnd_poisson+" -- "+sum);
        
        if(tiempo != 0){
            //System.out.println("tiempo"+tiempo);
            tiempo_paciente(tiempo+1);
        }
    }
    
    void tabla_poisson(){
        poisson_m=new double[minutos][];
        for (int i = 1; i < minutos; i++) {
            poisson_m[i]=new double[3];
            poisson_m[i][0] = i;
            poisson_m[i][1] = poisson(i);
            double acum = (i == 1)?poisson_m[i][1]: poisson_m[i-1][2]+poisson_m[i][1];
            poisson_m[i][2] = redondearDecimales(acum, 3);
            //poisson_m[i][3] = rnd_poisson;
        }
        
    }
    
    void tiempo_paciente(int j){
        
        //System.out.println(rnd_poisson+" -- "+j+" -- "+tiempo+" -- "+sum);
        //System.out.println("->["+poisson_m[j][2]+"]");
        if(j >= minutos || sum >= minutos){
            //System.out.println("MUEREEEEE "+j+" -- "+sum);
        }else{
            if(rnd_poisson >= poisson_m[j][2] && rnd_poisson < poisson_m[j+1][2]){
                //System.out.println("->>>>>>["+final_m[j][0]+"]");
                final_m[j][1] = paciente;
                final_m[j][2] = paciente;
                tiempo = j;
                sum += final_m[j][0];
                paciente++;
                determinar_poisson();

            } else {
                tiempo_paciente(j+1);
            }
        }
    }
    
    void mostrar(){
        for (int i = 1; i < minutos; i++) {
            for (int j = 0; j < final_m[i].length; j++) {
                System.out.print("   ["+final_m[i][j]+"]");
            }
            System.out.println("");
        }
    }
    
    
    
    /*void ingreso_paciente(int i){
        System.out.println("->"+ poisson_m[i][1]);
        double pos = poisson_m[i][1];
        paciente++;
        if(paciente == 1){
            poisson_m[pos][2] = paciente;
        } else {
            //poisson_m[(i+1)][2] = paciente;
        }
        
    }*/
    
    private void mostrar_matriz(double m[]) {
        for (int j = 0; j < m.length; j++) {
            System.out.print("  [" + m[j] + "] ");
        }
        System.out.println("");
    }
    
    double acumulada(double primero, double anterior){
        return primero + anterior;
    }
    
    public static double redondearDecimales(double valorInicial, int numeroDecimales) {
        double parteEntera, resultado;
        resultado = valorInicial;
        parteEntera = Math.floor(resultado);
        resultado = (resultado - parteEntera) * Math.pow(10, numeroDecimales);
        resultado = Math.round(resultado);
        resultado = (resultado / Math.pow(10, numeroDecimales)) + parteEntera;
        return resultado;
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        Urgencias ur = new Urgencias();
        ur.tiempo_entrada(40);
        
    }
    
}
