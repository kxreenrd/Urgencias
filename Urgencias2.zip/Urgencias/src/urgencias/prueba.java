/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package urgencias;

/**
 *
 * @author Karen Rodriguez
 */
public class prueba {
    
}

/*
 * Integrantes 
Jonathan Ahumada & Karen Rodriguez
 */
package compania_autos;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/**
 *
 * @author Administrador
 */
public class compania extends JFrame{

    double a_disponibles = 0, a_rentados = 0, dias = 0, cant_a = 0, diast = 365;
    int dinero = 0;
    double diasrnd[][] = new double[4][3];
    double Matriz[][] = new double[5][3];
    double[][] vista;
    int[][] mat;

    List dias_alquilado = new ArrayList();
    List costo = new ArrayList();
    
    

    private int calcular_diasxauto(int cant) {
        int ano = 365;
        cant_a = cant;
        int disp = 0;
        System.out.println("CANTIDAD DE AUTOS " + cant);
        if(cant == 0){
            dinero -= 200;
            System.out.println("No hay autos disponibles");
        } else {
            System.out.print("  [DIA]");
            System.out.print(" [AUTO]");
            System.out.print(" [D. ALQ.]");
            System.out.print("  [DISPONIBILIDAD]");
            System.out.print("  [DINERO] \n");
            //vista = new double[cant][10];
            mat=new int[ano][];

            for (int i=0;i<mat.length;i++) {
                a_disponibles = cant;
                double random = redondearDecimales(Math.random(), 2);

                mat[i]=new int[5];              
                for (int j = 1; j <= cant; j++) { 
                    //System.out.println("dias "+dias);
                    if (dias < i) {
                        disp = 1;
                        dias = i + (diasxauto(random));
                        dinero += 350;
                    } else if(dias == 0 ){
                        dinero += 0;
                        disp = 1;
                    } else {
                        dinero -= 200;
                        disp = 0;
                        dias = 0;
                    }

                    mat[i][0] = (i+1);
                    mat[i][1] = j;
                    mat[i][2] = diasxauto(random);
                    mat[i][3] = disp;
                    mat[i][4] = dinero;
                    mostrar_matriz(mat[i]);
                }
                //System.out.println("dinero por día "+i+ " dinero: "+dinero);
            }
            System.out.println("-----------------------------------------------");
            
            //mostrar_matriz(mat);
        }
        return dinero;
    }
    

    private int diasxauto(double random) {
        //double random = redondearDecimales(Math.random(), 2);
        int v = 0;
        if (random > 0 && random <= diasrnd[0][2]) {
            v = 1;
        } else if (random > diasrnd[0][2] && random <= diasrnd[1][2]) {
            v = 2;
        } else if (random > diasrnd[1][2] && random <= diasrnd[2][2]) {
            v = 3;
        } else if (random > diasrnd[2][2] && random <= diasrnd[3][2]) {
            v = 4;
        } else if(random == 0){
            v = 0;
        }
        return v;
    }
    
    private int calcular_autosxdia(){
        dinero = 0;
        double random = redondearDecimales(Math.random(), 2);
        //System.out.println("Random autosxdia: "+random);
        int num = 0;
        if(random > 0 && random <= Matriz[0][2]){
            num = 0;
        } else if(random > Matriz[0][2] && random <= Matriz[1][2]){
            num = 1;
        } else if(random > Matriz[1][2] && random <= Matriz[2][2]){
            num = 2;
        }else if(random > Matriz[2][2] && random <= Matriz[3][2]){
            num = 3;
        } else if(random > Matriz[3][2] && random <= Matriz[4][2]){
            num = 4;
        }
        return num;
    }

    public static double redondearDecimales(double valorInicial, int numeroDecimales) {
        double parteEntera, resultado;
        resultado = valorInicial;
        parteEntera = Math.floor(resultado);
        resultado = (resultado - parteEntera) * Math.pow(10, numeroDecimales);
        resultado = Math.round(resultado);
        resultado = (resultado / Math.pow(10, numeroDecimales)) + parteEntera;
        return resultado;
    }

    private void matrices() {
        Matriz[0][0]=(double)0;
        Matriz[1][0]=(double)1;
        Matriz[2][0]=(double)2;
        Matriz[3][0]=(double)3;
        Matriz[4][0]=(double)4;
        
        Matriz[0][1]=(double)0.10;
        Matriz[1][1]=(double)0.10;
        Matriz[2][1]=(double)0.25;
        Matriz[3][1]=(double)0.30;
        Matriz[4][1]=(double)0.25;
        
        Matriz[0][2]=(double)0.10;
        Matriz[1][2]=(double)0.20;
        Matriz[2][2]=(double)0.45;
        Matriz[3][2]=(double)0.75;
        Matriz[4][2]=(double)1;

        diasrnd[0][0] = (double) 1;
        diasrnd[1][0] = (double) 2;
        diasrnd[2][0] = (double) 3;
        diasrnd[3][0] = (double) 4;

        diasrnd[0][1] = (double) 0.40;
        diasrnd[1][1] = (double) 0.35;
        diasrnd[2][1] = (double) 0.15;
        diasrnd[3][1] = (double) 0.10;

        diasrnd[0][2] = (double) 0.40;
        diasrnd[1][2] = (double) 0.75;
        diasrnd[2][2] = (double) 0.90;
        diasrnd[3][2] = (double) 1;
    }

    private void mostrar_matriz(int m[]) {
        for (int j = 0; j < m.length; j++) {
            
            if(j == 3){
                String dat = m[j] == 0? "Alquilado ": "Disponible";
                System.out.print("       [" +  dat + "]");
            }else{
                System.out.print("    [" + m[j] + "]");
            }
        }
        System.out.println("");
    }
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        compania ca = new compania();        
        ca.matrices();
        System.out.println("ingrese la cantidad de años para hacer la simulación");
        int cant = sc.nextInt();
        int v[][] = new int[cant][3];
        for (int i = 0; i < cant; i++) {
            int c = ca.calcular_autosxdia();
            System.out.print("\nAÑO: "+(i+1)+"  |  ");
            v[i][1] = ca.calcular_diasxauto(c);
            v[i][0] = i+1;
            v[i][2] = c;
        }
        System.out.print("\n[AÑO] [DINERO][CANTIDAD AUTOS]");
        for (int i = 0; i < v.length; i++) {
            System.out.println("");
            for (int j = 0; j < v[i].length; j++) {
                System.out.print("["+v[i][j]+"]    ");
            }
        }
        System.out.println("");
        
        
    }
}

