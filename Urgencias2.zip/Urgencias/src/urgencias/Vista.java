/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package urgencias;

/**
 *
 * @author Karen Rodriguez
 */
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;

public class Vista extends JFrame {
    Object[][] datos = {{new Integer(0), new Double(0), new Double(0), new Double(0),new Double(0)}};
    String[] columnNames = {"Minutos", "Poisson", "F(x)","Random", "Tiempo"};
    DefaultTableModel dtm = new DefaultTableModel(datos, columnNames);
    final JTable table = new JTable(dtm);
    
    public Vista() {  
        // Agregar nueva columna
        //String[] columnaNueva1 = {"vago", "diestro", "normal",};
        //dtm.addColumn("Tipo", columnaNueva1);

        // Modificar celda especifica
        //dtm.setValueAt("XXX", 3, 3); // Row/Col
        Urgencias u = new Urgencias();
        dtm.addRow(u.tiempo_entrada(20));
        
        table.setPreferredScrollableViewportSize(new Dimension(600, 200));//ancho, largo
        JScrollPane scrollPane = new JScrollPane(table);
        getContentPane().add(scrollPane, BorderLayout.CENTER);
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }
    
    public void nueva_fila(Object[] newRow){
        dtm.addRow(newRow);
    }

    public static void main(String[] args) {
        Vista frame = new Vista();
        frame.pack();
        frame.setVisible(true);
    }
}
